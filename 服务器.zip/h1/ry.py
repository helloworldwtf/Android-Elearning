import numpy as np

print("nannyjiijjo")
cv=[]
cv=np.array(cv)
setattr()
license()